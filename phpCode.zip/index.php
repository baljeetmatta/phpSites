<html>
    <body>
        <?php 
       /* echo "Hello"."cat";
        $a=10;
        echo $a;
        echo "Hello $a";*/
      /*  $a=10;
        var_dump($A);
        $a="Hello";
        var_dump($a);
*/
//         define("num",50,true);
        
//         $code= function()
//         {
//             echo "Test called".num;
//         };

// $code();

// $age=array(10,20,"car");
// echo $age[0];
// $names=["cat","dog","rat"];
// echo $names[1];
// $info[0]="cat";
// $info[1]="dog";
// $info[2]="rat";

//      $age=["cat"=>"100","dog"=>"20","rat"=>"30"];
//     // echo count($age);
//     foreach($age as $key=> $value)
//     {
//         echo $key." ". $value."<br/>";
//     }
// $data="This is a word";
// $output=explode(" ",$data,-2);
// print_r($output);
echo "GEt Data <br/>";
print_r($_GET);
echo "POST Data <br/>";

print_r($_POST);

echo "REUEST Data <br/>";

print_r($_REQUEST)

        ?>
</body>

    </html>