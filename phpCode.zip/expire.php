<html>
    <body>
        <?php
        setcookie("user","",time()-3600,"/"); //delete cookie
        ?>

    </body>
</html>